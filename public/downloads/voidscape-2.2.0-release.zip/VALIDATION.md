# Voidscape 2.2 validation — 2026-09-09

## Build and artifact scope

Release compiled with `javac --release 25` into a unique output directory, independent of IDE incremental output. Maven resolves dependencies. Resource pack artwork remains compatible with 2.1; its Java/Geyser IDs and hashes are unchanged. Only the source workspace and an isolated local test server were modified; no production server was updated.

## Automated checks

- Geometry: original dungeon placement, spawn exclusion, floor seals and walkable route to the ship deck.
- Terrain: 381 landmark placements, all three variants, exclusion from dungeons/spawn, positive/negative chunk boundaries, deterministic output, supported markers and border-bounded scout.
- Expedition rules: 1,000 seeds, all three mechanics per route, no consecutive identical stages or rune pads, final hunt, rank bounds, invalid difficulty rejection and reward totals for all three difficulties.
- Packs: custom model references, item/block atlas paths, PNG CRCs, eight Java/Geyser ID mappings, vanilla fallbacks and SHA-1 hashes.
- Isolated Paper 26.2-121 on Java 26: 51 assertions passed with real chunks, entities, inventories and reward ledger, using simulated player connections. Covers the existing dungeon/claim/relic checks plus expedition start/unlocks, walking rune sequences, wrong-rune failure, storm hit/dodge, timeout, guardian deaths, arena exit, disconnect, full inventory, reward/XP replay protection, risk continuation, final champion, automatic final extraction and shutdown banking. GUI event cancellation and stale extraction selections were checked; menu selection logic is also invoked directly to simulate the deferred inventory action.

## Performance constraints

The existing 10-tick task also services expeditions; no separate repeating task, chunk loading, generated terrain or display entities are added by the expedition system. Defaults cap expeditions at two and combined dungeons/expeditions at four. The shared mob ceiling is 48. Each hunt adds one to three tracked guardians; marker/hazard particles are private to the owner, bounded at roughly 40 per second per active run. Ground searches only happen on start and are throttled, including failed searches.

These are implementation limits, not a multiplayer load test. Active gameplay TPS/MSPT and Java/Bedrock FPS were not measured. Player targeting/pathfinding with a live connection, actual GUI/book rendering, particle visibility through Geyser, pack HTTP downloads, and interactions with third-party protection/resource-pack plugins still need client/server playtesting. No guarantee of zero lag is made.

## Persistence behavior

Extracted shards and explorer XP share the existing durable reward receipt ledger. A full inventory defers both until `/void claim`. Graceful plugin shutdown banks completed stages. Disconnects and leaving the arena forfeit unbanked progress; abrupt process failure can also lose unbanked progress. Cooldowns persist from the start of the run.

The Java resource pack is not hosted. Configure its HTTPS URL/SHA-1 and install the Bedrock pack/mappings through Geyser as described in README.md. Expedition gameplay works on existing terrain without generating new chunks; the earlier scenery additions still require ungenerated chunks.

## Verified JAR SHA-256

`ca6990fa66d72a9fd2db0f4ee7cc4c8ad943b9acae11d6dd2d9e622647a662ed`
